"use client";

import { useActionState, useEffect, useRef } from "react";
import { useFormStatus } from "react-dom";
import { useToast } from "@/hooks/use-toast";
import { submitContactForm, type FormState } from "@/lib/actions";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { Send } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";

function SubmitButton() {
  const { pending } = useFormStatus();
  return (
    <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
      <Button
        type="submit"
        disabled={pending}
        className="w-full bg-primary hover:bg-primary/90 text-primary-foreground py-6 rounded-md shadow-lg group text-lg"
      >
        {pending ? "Sending..." : "Send Message"}
        <Send className="ml-2 group-hover:translate-x-1 transition-transform" size={20} />
      </Button>
    </motion.div>
  );
}

export function ContactForm() {
  const initialState: FormState = { success: false, message: "" };
  const [state, formAction] = useActionState(submitContactForm, initialState);
  const { toast } = useToast();
  const formRef = useRef<HTMLFormElement>(null);

  useEffect(() => {
    if (state.message) {
      if (state.success) {
        toast({
          title: "Success!",
          description: state.message,
        });
        formRef.current?.reset();
      } else {
        toast({
          title: "Error",
          description: state.message,
          variant: "destructive",
        });
      }
    }
  }, [state, toast]);
  
    const industries = [
    'Engineering & Machinery',
    'Textiles & Garments',
    'Food & Beverages',
    'Pharmaceuticals',
    'Gems & Jewelry',
    'Electronics & IT',
    'Chemicals & Plastics',
    'Home & Lifestyle',
    'Other',
  ];

  return (
    <div className="bg-gradient-to-br from-gray-900 to-gray-800 p-8 sm:p-12 rounded-2xl shadow-2xl">
        <div className="text-center mb-8">
            <h2 className="text-white mb-2 font-headline">Send Us a Message</h2>
            <p className="text-gray-400">
                Fill out the form below and our team will get back to you within 24 hours
            </p>
        </div>
        <form ref={formRef} action={formAction} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <Label htmlFor="name" className="text-gray-300">Full Name *</Label>
                    <Input
                        id="name"
                        name="name"
                        required
                        className="mt-1 bg-gray-800 border-gray-700 text-white placeholder:text-gray-500"
                        placeholder="Your name"
                    />
                </div>
                <div>
                    <Label htmlFor="email" className="text-gray-300">Email Address *</Label>
                    <Input
                        id="email"
                        name="email"
                        type="email"
                        required
                        className="mt-1 bg-gray-800 border-gray-700 text-white placeholder:text-gray-500"
                        placeholder="your@email.com"
                    />
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <Label htmlFor="phone" className="text-gray-300">Phone Number *</Label>
                    <Input
                        id="phone"
                        name="phone"
                        type="tel"
                        required
                        className="mt-1 bg-gray-800 border-gray-700 text-white placeholder:text-gray-500"
                        placeholder="+91 XXXXX XXXXX"
                    />
                </div>
                <div>
                    <Label htmlFor="company" className="text-gray-300">Company Name</Label>
                    <Input
                        id="company"
                        name="company"
                        className="mt-1 bg-gray-800 border-gray-700 text-white placeholder:text-gray-500"
                        placeholder="Your company"
                    />
                </div>
            </div>
            
            <div>
                <Label htmlFor="industry" className="text-gray-300">Industry *</Label>
                <Select name="industry" required>
                    <SelectTrigger id="industry" className="mt-1 bg-gray-800 border-gray-700 text-white">
                        <SelectValue placeholder="Select your industry" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-700 text-white">
                        {industries.map((industry) => (
                            <SelectItem key={industry} value={industry} className="focus:bg-primary focus:text-primary-foreground">
                                {industry}
                            </SelectItem>
                        ))}
                    </SelectContent>
                </Select>
            </div>

            <div>
                <Label htmlFor="message" className="text-gray-300">Message *</Label>
                <Textarea
                    id="message"
                    name="message"
                    required
                    rows={5}
                    className="mt-1 bg-gray-800 border-gray-700 text-white placeholder:text-gray-500"
                    placeholder="Tell us about your export goals..."
                />
            </div>
            <SubmitButton />
        </form>
    </div>
  );
}
