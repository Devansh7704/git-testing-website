
"use client";

import { useState } from 'react';
import { usePathname } from 'next/navigation';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { Logo } from './logo';
import { MobileNav } from './mobile-nav';
import { NAV_LINKS } from '@/lib/constants';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { ChevronDown } from 'lucide-react';
import { Button } from '../ui/button';

export function Header() {
  const pathname = usePathname();
  const [hoveredLink, setHoveredLink] = useState<string | null>(null);

  const mainLinks = NAV_LINKS.filter(link =>
    ['/', '/about', '/services'].includes(link.href)
  ).map(link => ({...link, label: link.href === '/' ? 'Home': link.label}));

  const moreLinks = NAV_LINKS.filter(
    link => !mainLinks.some(mainLink => mainLink.href === link.href)
  );

  const isMoreActive = moreLinks.some(link => link.href === pathname);
  const contactLink = { href: '/contact', label: 'Contact Us' };

  return (
    <motion.header
      className="relative z-50 bg-white shadow-md"
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="container flex h-20 items-center justify-between">
        <Logo />

        <nav
          className="hidden lg:flex items-center space-x-1"
          onMouseLeave={() => setHoveredLink(null)}
        >
          {mainLinks.map(item => {
            const isActive = pathname === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                className="relative block px-4 py-2"
                onMouseEnter={() => setHoveredLink(item.href)}
              >
                <span className="relative text-sm font-medium transition-colors text-gray-700 hover:text-primary">
                  {item.label}
                </span>
                {(isActive || hoveredLink === item.href) && (
                  <motion.div
                    layoutId="underline"
                    className="absolute bottom-0 left-1/4 right-1/4 h-1 w-1/2 rounded-full bg-primary"
                    transition={{ type: 'spring', stiffness: 300, damping: 20 }}
                  />
                )}
              </Link>
            );
          })}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <div
                className="relative"
                onMouseEnter={() => setHoveredLink('more')}
              >
                <Button
                  variant="ghost"
                  className="px-4 py-2 rounded-md transition-colors text-sm font-medium text-gray-700 hover:bg-transparent hover:text-primary"
                >
                  More <ChevronDown className="ml-1 h-4 w-4" />
                </Button>
                {(isMoreActive || hoveredLink === 'more') && (
                  <motion.div
                    layoutId="underline"
                    className="absolute bottom-0 left-1/4 right-1/4 h-1 w-1/2 rounded-full bg-primary"
                    transition={{ type: 'spring', stiffness: 300, damping: 20 }}
                  />
                )}
              </div>
            </DropdownMenuTrigger>
            <DropdownMenuContent onMouseLeave={() => setHoveredLink(null)}>
              {moreLinks.map(item => (
                <DropdownMenuItem key={item.href} asChild>
                  <Link
                    href={item.href}
                    className={
                      pathname === item.href ? 'bg-primary/10 text-primary' : ''
                    }
                  >
                    {item.label}
                  </Link>
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </nav>
        
        <div className="hidden lg:flex items-center">
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button asChild>
                    <Link href={contactLink.href}>{contactLink.label}</Link>
                </Button>
            </motion.div>
        </div>

        <MobileNav />
      </div>
    </motion.header>
  );
}
