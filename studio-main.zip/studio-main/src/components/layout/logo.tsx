
"use client";

import Link from 'next/link';
import { motion } from 'framer-motion';
import Image from 'next/image';
import { cn } from '@/lib/utils';

type LogoProps = {
  variant?: 'default' | 'light';
};

export function Logo({ variant = 'default' }: LogoProps) {
  return (
    <Link href="/" passHref>
      <motion.div
        className="flex items-center cursor-pointer"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        <Image src="/logo.png" alt="Rising Venture Services" width={48} height={48} />
        <div className="ml-3">
          <div
            className={cn(
              "text-lg font-headline font-semibold",
              variant === 'light' ? 'text-white' : 'text-gray-900'
            )}
          >
            Rising Venture Services
          </div>
          <div
            className={cn(
              "text-xs",
              variant === 'light' ? 'text-gray-300' : 'text-gray-600'
            )}
          >
            Empowering Global Growth
          </div>
        </div>
      </motion.div>
    </Link>
  );
}
