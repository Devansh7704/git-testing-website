
'use client';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { Mail, Phone, Globe, MapPin, ArrowUpRight } from 'lucide-react';
import { NAV_LINKS } from '@/lib/constants';
import { Logo } from './logo';

export function Footer() {
  const mainNavLinks = NAV_LINKS.filter(link => link.href !== '/');
  const quickLinks = mainNavLinks.slice(0, 4);
  const moreLinks = mainNavLinks.slice(4);

  return (
    <footer className="bg-gray-900 text-white">
      <div className="container py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <div className="bg-white rounded-lg p-4 inline-block mb-4">
               <Logo />
            </div>
            <p className="text-gray-400">
              Empowering Indian businesses to achieve global success through expert export development services.
            </p>
          </div>

          <div>
            <h3 className="mb-4 font-semibold text-lg font-headline">Quick Links</h3>
            <ul className="space-y-2">
              {quickLinks.map((item) => (
                <li key={item.href}>
                  <Link href={item.href} passHref>
                    <motion.div
                      className="text-gray-400 hover:text-primary transition-colors flex items-center group cursor-pointer"
                      whileHover={{ x: 4 }}
                    >
                      <ArrowUpRight size={14} className="mr-1 opacity-0 group-hover:opacity-100 transition-opacity" />
                      {item.label}
                    </motion.div>
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="mb-4 font-semibold text-lg font-headline">More</h3>
            <ul className="space-y-2">
              {moreLinks.map((item) => (
                <li key={item.href}>
                  <Link href={item.href} passHref>
                    <motion.div
                      className="text-gray-400 hover:text-primary transition-colors flex items-center group cursor-pointer"
                      whileHover={{ x: 4 }}
                    >
                      <ArrowUpRight size={14} className="mr-1 opacity-0 group-hover:opacity-100 transition-opacity" />
                      {item.label}
                    </motion.div>
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="mb-4 font-semibold text-lg font-headline">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-start text-gray-400">
                <MapPin size={18} className="mr-2 mt-1 text-primary flex-shrink-0" />
                <span>Ahmedabad, Gujarat, India</span>
              </li>
              <li className="flex items-center text-gray-400">
                <Phone size={18} className="mr-2 text-primary flex-shrink-0" />
                <span>+91 XXX XXX XXXX</span>
              </li>
              <li className="flex items-center text-gray-400">
                <Mail size={18} className="mr-2 text-primary flex-shrink-0" />
                <span>info@risingventure.com</span>
              </li>
              <li className="flex items-center text-gray-400">
                <Globe size={18} className="mr-2 text-primary flex-shrink-0" />
                <span>www.risingventure.com</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center text-gray-400 text-sm">
            <p>© {new Date().getFullYear()} Rising Venture Services. All rights reserved.</p>
            <p className="mt-2 md:mt-0">
              Together, let's make your business a global success story.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
