
'use client';

import {
  Search,
  TrendingUp,
  Users,
  Target,
  Globe,
  Award,
  CheckCircle,
  ArrowRight,
  BarChart,
  Package,
  Handshake,
  FileText,
  Megaphone,
  Monitor,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { motion } from 'framer-motion';

export default function ServicesPage() {
  const mainServices = [
    {
      icon: Search,
      title: 'Market Research & Analysis',
      description:
        'Comprehensive market intelligence to identify the best opportunities for your products',
      features: [
        'Global market trends analysis',
        'Competitor landscape mapping',
        'Target market identification',
        'Demand forecasting & insights',
        'Entry strategy recommendations',
      ],
      color: 'from-blue-500 to-blue-600',
    },
    {
      icon: Megaphone,
      title: 'Marketing & Branding',
      description:
        'Strategic brand positioning to make your products stand out in international markets',
      features: [
        'International brand development',
        'Digital marketing strategies',
        'Trade show presentations',
        'Marketing collateral design',
        'Online presence optimization',
      ],
      color: 'from-purple-500 to-purple-600',
    },
    {
      icon: Handshake,
      title: 'Buyer Development',
      description:
        'Connect with verified international buyers and build lasting business relationships',
      features: [
        'Buyer identification & verification',
        'B2B matchmaking services',
        'Negotiation support',
        'Partnership facilitation',
        'Long-term relationship management',
      ],
      color: 'from-green-500 to-green-600',
    },
    {
      icon: Package,
      title: 'Export Documentation',
      description:
        'Streamline your export process with expert documentation and compliance support',
      features: [
        'Export documentation assistance',
        'Compliance verification',
        'Customs clearance support',
        'Shipping coordination',
        'Trade finance guidance',
      ],
      color: 'from-orange-500 to-orange-600',
    },
    {
      icon: BarChart,
      title: 'Business Development',
      description:
        'Strategic planning and execution to scale your international operations',
      features: [
        'Export strategy development',
        'Market entry planning',
        'Distribution channel setup',
        'Performance tracking',
        'Growth optimization',
      ],
      color: 'from-red-500 to-red-600',
    },
    {
      icon: Globe,
      title: 'Global Network Access',
      description:
        'Leverage our extensive network of international partners and trade associations',
      features: [
        'Trade association connections',
        'International partner network',
        'Exhibition participation',
        'Trade mission coordination',
        'Government liaison support',
      ],
      color: 'from-indigo-500 to-indigo-600',
    },
  ];

  const processSteps = [
    {
      number: '01',
      title: 'Initial Consultation',
      description:
        'Understanding your business goals, products, and export readiness',
      icon: Users,
    },
    {
      number: '02',
      title: 'Market Research',
      description:
        'Identifying the most profitable markets and opportunities for your products',
      icon: Search,
    },
    {
      number: '03',
      title: 'Strategy Development',
      description:
        'Creating a customized export plan tailored to your business',
      icon: Target,
    },
    {
      number: '04',
      title: 'Implementation',
      description:
        'Executing the strategy with full documentation and buyer connection support',
      icon: CheckCircle,
    },
    {
      number: '05',
      title: 'Ongoing Support',
      description: 'Continuous optimization, monitoring, and growth assistance',
      icon: TrendingUp,
    },
  ];

  const additionalServices = [
    {
      icon: Monitor,
      title: 'Digital Presence',
      description:
        'Website development, SEO, and online marketing for global visibility',
    },
    {
      icon: FileText,
      title: 'Compliance Training',
      description:
        'Expert training on export regulations and international trade compliance',
    },
    {
      icon: Award,
      title: 'Certification Support',
      description:
        'Assistance with quality certifications and product standards',
    },
    {
      icon: Globe,
      title: 'Market Entry',
      description: 'On-ground support for entering new international markets',
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden bg-gradient-to-br from-primary to-red-700 pt-20">
        <motion.div
          className="absolute inset-0 opacity-10"
          animate={{
            backgroundPosition: ['0% 0%', '100% 100%'],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            repeatType: 'reverse',
          }}
          style={{
            backgroundImage:
              'radial-gradient(circle, white 2px, transparent 2px)',
            backgroundSize: '50px 50px',
          }}
        />

        <div className="relative container text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-white mb-4 font-headline">
              Our Services
            </h1>
            <p className="text-red-100 max-w-3xl mx-auto">
              Comprehensive export development solutions to help your business succeed in global markets
            </p>
          </motion.div>
        </div>
      </section>

      {/* All Services */}
      <section className="py-20 bg-background">
        <div className="container">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5}}
          >
            <h2 className="text-foreground mb-4 font-headline">Complete Export Solutions</h2>
            <p className="text-muted-foreground max-w-3xl mx-auto">
              Everything you need to expand your business into international
              markets
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {mainServices.map((service, index) => (
              <motion.div
                key={index}
                className="bg-white rounded-2xl shadow-lg overflow-hidden border-2 border-gray-100 hover:border-primary transition-all duration-300 group"
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ y: -8, scale: 1.02 }}
              >
                <div
                  className={`bg-gradient-to-r ${service.color} p-6 text-white`}
                >
                  <motion.div
                    className="w-14 h-14 bg-white/20 rounded-xl flex items-center justify-center mb-4"
                    whileHover={{ rotate: 360, scale: 1.1 }}
                    transition={{ duration: 0.6 }}
                  >
                    <service.icon size={28} />
                  </motion.div>
                  <h3 className="text-white font-headline">{service.title}</h3>
                </div>

                <div className="p-6">
                  <p className="text-muted-foreground mb-6 text-base">
                    {service.description}
                  </p>

                  <ul className="space-y-3">
                    {service.features.map((feature, fIndex) => (
                      <li
                        key={fIndex}
                        className="flex items-start text-sm text-foreground"
                      >
                        <CheckCircle
                          className="text-green-500 mr-2 mt-0.5 flex-shrink-0"
                          size={16}
                        />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Our Process */}
       <section className="py-20 bg-gray-50 overflow-hidden">
        <div className="container">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, once: true }}
            viewport={{ once: true }}
          >
            <h2 className="text-foreground mb-4 font-headline">Our Process</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              A systematic, step-by-step approach to ensure your export success
            </p>
          </motion.div>

          <div className="relative w-full">
             <motion.div
                className="flex"
                animate={{
                  x: ['0%', '-100%'],
                }}
                transition={{
                  ease: 'linear',
                  duration: 25,
                  repeat: Infinity,
                }}
              >
                {[...processSteps, ...processSteps].map((step, index) => (
                <motion.div
                  key={index}
                  className="flex-shrink-0 w-80 bg-white rounded-2xl shadow-lg p-8 relative overflow-hidden group mx-4"
                  initial={{ opacity: 0, y: 50 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: (index % processSteps.length) * 0.1, once: true }}
                  viewport={{ once: true }}
                >
                  <div className="absolute -right-8 -top-8 text-[120px] font-bold text-gray-100/80 transition-transform duration-300 group-hover:scale-110">
                    {step.number}
                  </div>
                  <div className="relative z-10">
                    <div className="w-16 h-16 bg-primary rounded-xl flex items-center justify-center mb-6 shadow-lg">
                      <step.icon className="text-white" size={32} />
                    </div>
                    <h3 className="text-foreground mb-3 font-headline text-xl">
                      {step.title}
                    </h3>
                    <p className="text-muted-foreground text-base">
                      {step.description}
                    </p>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </div>
      </section>

      {/* Additional Services */}
      <section className="py-20 bg-background">
        <div className="container">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, once: true }}
            viewport={{ once: true }}
          >
            <h2 className="text-foreground mb-4 font-headline">Additional Services</h2>
            <p className="text-muted-foreground max-w-3xl mx-auto">
              Extra support to enhance your export capabilities
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {additionalServices.map((service, index) => (
              <motion.div
                key={index}
                className="bg-gradient-to-br from-gray-50 to-white p-6 rounded-xl border-2 border-gray-100 hover:border-primary transition-all duration-300 text-center"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1, once: true }}
                viewport={{ once: true }}
              >
                <div className="inline-flex w-16 h-16 bg-red-100 rounded-full items-center justify-center mb-4">
                  <service.icon className="text-primary" size={28} />
                </div>
                <h3 className="text-foreground mb-2 font-headline">{service.title}</h3>
                <p className="text-muted-foreground text-base">
                  {service.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Banner */}
      <section className="py-20 bg-gradient-to-br from-primary to-red-700 text-white">
        <div className="container text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, once: true }}
            viewport={{ once: true }}
          >
            <h2 className="text-white mb-6 font-headline">
              Ready to Start Your Export Journey?
            </h2>
            <p className="text-red-100 mb-8 max-w-3xl mx-auto">
              Let's discuss how our comprehensive services can help your
              business reach new international markets and achieve sustainable
              growth
            </p>

            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button asChild
                variant="secondary"
                size="lg"
                className="px-12 py-6 rounded-lg shadow-lg group"
              >
                <Link href="/contact">
                  Get Started
                  <ArrowRight
                    className="ml-2 group-hover:translate-x-1 transition-transform"
                    size={20}
                  />
                </Link>
              </Button>
            </motion.div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
