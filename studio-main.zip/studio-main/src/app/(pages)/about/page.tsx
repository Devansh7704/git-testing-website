'use client';

import {
  Target,
  Eye,
  Heart,
  Award,
  Users,
  Globe,
  CheckCircle,
} from 'lucide-react';
import { motion } from 'framer-motion';

export default function AboutPage() {
  const missionPoints = [
    'Comprehensive export development services',
    'Customized solutions for every business',
    'Bridging Indian manufacturers with global markets',
    'Enabling confident international trade navigation',
  ];

  const visionPoints = [
    'Most trusted export development partner',
    'Fostering sustainable business growth',
    'Making "Made in India" a global mark of excellence',
    'Empowering businesses with innovative solutions',
  ];

  const values = [
    {
      icon: Heart,
      title: 'Integrity',
      description:
        'We build relationships on trust and transparency, ensuring every partnership is founded on honesty and ethical practices.',
    },
    {
      icon: Award,
      title: 'Excellence',
      description:
        'Our commitment to excellence drives us to deliver exceptional results and exceed expectations in every project we undertake.',
    },
    {
      icon: Users,
      title: 'Partnership',
      description:
        'Your success is our success. We work collaboratively with our clients, building strong, long-term partnerships for mutual growth.',
    },
    {
      icon: Globe,
      title: 'Global Vision',
      description:
        'We think globally and act strategically, providing our clients with the insights and connections needed to thrive in international markets.',
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden bg-gradient-to-br from-primary to-red-700 pt-20">
        <motion.div
          className="absolute inset-0 opacity-10"
          animate={{
            backgroundPosition: ['0% 0%', '100% 100%'],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            repeatType: 'reverse',
          }}
          style={{
            backgroundImage:
              'radial-gradient(circle, white 2px, transparent 2px)',
            backgroundSize: '50px 50px',
          }}
        />

        <div className="relative container text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-white mb-4 font-headline">
              About Rising Venture Services
            </h1>
            <p className="text-red-100 max-w-3xl mx-auto">
              Pioneering global trade partnerships for Indian businesses
            </p>
          </motion.div>
        </div>
      </section>

      {/* Who We Are */}
      <section className="py-20 bg-background">
        <div className="container">
          <motion.div
            className="text-center mb-12"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-foreground mb-6 font-headline">Who We Are</h2>
            <p className="text-muted-foreground max-w-4xl mx-auto">
              Rising Venture Services is a premier export development
              consultancy dedicated to helping Indian businesses expand their
              global footprint. With deep expertise in international trade,
              market intelligence, and buyer connections, we provide end-to-end
              solutions that transform export aspirations into tangible success.
              Our team of industry experts works closely with businesses across
              diverse sectors to navigate the complexities of global markets
              and build lasting international partnerships.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Our Mission */}
      <section className="py-20 bg-gray-50">
        <div className="container">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-foreground mb-4 font-headline">Our Mission</h2>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              className="bg-gradient-to-br from-red-50 to-white p-8 lg:p-12 rounded-2xl border-2 border-red-100"
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              viewport={{ once: true }}
            >
              <div className="w-16 h-16 bg-primary rounded-xl flex items-center justify-center mb-6">
                <Target className="text-primary-foreground" size={32} />
              </div>
              <h3 className="text-foreground mb-4 font-headline">
                Our Mission
              </h3>
              <p className="text-muted-foreground text-base">
                To provide comprehensive, customized export development
                services that bridge the gap between Indian manufacturers and
                global markets, enabling businesses to navigate international
                trade with confidence and achieve unprecedented success.
              </p>
            </motion.div>

            <div className="space-y-4">
              {missionPoints.map((point, index) => (
                <motion.div
                  key={index}
                  className="flex items-start gap-4 bg-white p-6 rounded-xl shadow-md"
                  initial={{ opacity: 0, x: 30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <div>
                    <CheckCircle
                      className="text-primary flex-shrink-0"
                      size={24}
                    />
                  </div>
                  <p className="text-muted-foreground text-base">{point}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Our Vision */}
      <section className="py-20 bg-background">
        <div className="container">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-foreground mb-4 font-headline">Our Vision</h2>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-4 order-2 lg:order-1">
              {visionPoints.map((point, index) => (
                <motion.div
                  key={index}
                  className="flex items-start gap-4 bg-white p-6 rounded-xl shadow-md"
                  initial={{ opacity: 0, x: -30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <div>
                    <CheckCircle
                      className="text-blue-600 flex-shrink-0"
                      size={24}
                    />
                  </div>
                  <p className="text-muted-foreground text-base">{point}</p>
                </motion.div>
              ))}
            </div>

            <motion.div
              className="bg-gradient-to-br from-blue-50 to-white p-8 lg:p-12 rounded-2xl border-2 border-blue-100 order-1 lg:order-2"
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              viewport={{ once: true }}
            >
              <div className="w-16 h-16 bg-blue-600 rounded-xl flex items-center justify-center mb-6">
                <Eye className="text-white" size={32} />
              </div>
              <h3 className="text-foreground mb-4 font-headline">Our Vision</h3>
              <p className="text-muted-foreground text-base">
                To be the most trusted and innovative partner in empowering
                Indian businesses to establish a strong global presence,
                fostering sustainable growth and making "Made in India" a mark
                of excellence worldwide.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Core Values */}
      <section className="py-20 bg-gray-50">
        <div className="container">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-foreground mb-4 font-headline">
              Our Core Values
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              The principles that guide everything we do
            </p>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 [perspective:1000px]">
            {values.map((value, index) => (
              <motion.div
                key={index}
                className="group h-64 w-full cursor-pointer"
                initial={{ opacity: 0, y: 50, rotateX: -20 }}
                whileInView={{ opacity: 1, y: 0, rotateX: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <div className="relative h-full w-full rounded-xl shadow-xl transition-all duration-500 [transform-style:preserve-3d] group-hover:[transform:rotateY(180deg)]">
                  {/* Front of Card */}
                  <div className="absolute inset-0 bg-gradient-to-br from-gray-100 to-white p-6 rounded-xl flex flex-col items-center justify-center [backface-visibility:hidden]">
                    <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                      <value.icon className="text-primary" size={40} />
                    </div>
                    <h3 className="text-foreground text-2xl font-headline">
                      {value.title}
                    </h3>
                  </div>

                  {/* Back of Card */}
                  <div className="absolute inset-0 h-full w-full rounded-xl bg-primary p-6 text-primary-foreground [transform:rotateY(180deg)] [backface-visibility:hidden]">
                    <div className="flex min-h-full flex-col items-center justify-center text-center">
                      <h3 className="text-xl font-bold mb-2">{value.title}</h3>
                      <p className="text-sm text-primary-foreground/80">
                        {value.description}
                      </p>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Message from Founders */}
      <section className="py-20 bg-background">
        <div className="container max-w-5xl">
          <motion.div
            className="bg-gradient-to-br from-primary to-red-700 p-8 lg:p-12 rounded-3xl text-white text-center shadow-2xl"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <div className="inline-flex w-20 h-20 bg-white/20 rounded-full items-center justify-center mb-8">
              <Users className="text-white" size={40} />
            </div>

            <h2 className="text-white mb-6 font-headline">
              Message from the Founders
            </h2>
            <p className="text-red-100 text-lg max-w-3xl mx-auto leading-relaxed">
              At RVS, we are driven by a singular vision: to help Indian
              manufacturers realize their global potential. With years of
              experience in international trade and a deep understanding of
              export dynamics, we are committed to providing personalized
              support that transforms export aspirations into tangible results.
            </p>
            <p className="text-white mt-6 text-xl">
              Let's build your global success story together.
            </p>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
