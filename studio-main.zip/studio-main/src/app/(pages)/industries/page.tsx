
'use client';

import { motion } from 'framer-motion';
import {
  Factory,
  Shirt,
  Utensils,
  Pill,
  Wrench,
  Cpu,
  Gem,
  Package,
  ArrowRight,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import Image from 'next/image';
import { PlaceHolderImages } from '@/lib/placeholder-images';

export default function IndustriesPage() {
  const factoryImage = PlaceHolderImages.find(p => p.id === 'factory-production');
  const textileImage = PlaceHolderImages.find(p => p.id === 'textile-manufacturing');
  const foodProcessingImage = PlaceHolderImages.find(p => p.id === 'food-processing');
  const pharmaImage = PlaceHolderImages.find(p => p.id === 'pharma-lab');
  const globalTradeImage = PlaceHolderImages.find(p => p.id === 'global-trade');

  const industries = [
    {
      icon: Wrench,
      title: 'Engineering & Machinery',
      description:
        'Precision engineering products and industrial machinery for global markets',
      image: factoryImage?.imageUrl,
      color: 'from-blue-500 to-blue-600',
    },
    {
      icon: Shirt,
      title: 'Textiles & Garments',
      description: 'High-quality fabrics, apparel, and textile products with global appeal',
      image: textileImage?.imageUrl,
      color: 'from-purple-500 to-purple-600',
    },
    {
      icon: Utensils,
      title: 'Food & Beverages',
      description:
        'Authentic Indian food products and beverages for international consumers',
      image: foodProcessingImage?.imageUrl,
      color: 'from-green-500 to-green-600',
    },
    {
      icon: Pill,
      title: 'Pharmaceuticals',
      description: 'Quality pharmaceutical products and healthcare solutions worldwide',
      image: pharmaImage?.imageUrl,
      color: 'from-red-500 to-red-600',
    },
    {
      icon: Gem,
      title: 'Gems & Jewelry',
      description: 'Exquisite jewelry and precious stones crafted with Indian artistry',
      image: factoryImage?.imageUrl,
      color: 'from-yellow-500 to-yellow-600',
    },
    {
      icon: Cpu,
      title: 'Electronics & IT',
      description:
        'Innovative electronic products and IT solutions for global tech markets',
      image: factoryImage?.imageUrl,
      color: 'from-indigo-500 to-indigo-600',
    },
    {
      icon: Factory,
      title: 'Chemicals & Plastics',
      description: 'Industrial chemicals and plastic products for diverse applications',
      image: factoryImage?.imageUrl,
      color: 'from-teal-500 to-teal-600',
    },
    {
      icon: Package,
      title: 'Home & Lifestyle',
      description:
        'Handicrafts, home decor, and lifestyle products with Indian heritage',
      image: factoryImage?.imageUrl,
      color: 'from-pink-500 to-pink-600',
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden bg-gradient-to-br from-primary to-red-700 pt-20">
        <motion.div
          className="absolute inset-0 opacity-10"
          animate={{
            backgroundPosition: ['0% 0%', '100% 100%'],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            repeatType: 'reverse',
          }}
          style={{
            backgroundImage:
              'radial-gradient(circle, white 2px, transparent 2px)',
            backgroundSize: '50px 50px',
          }}
        />

        <div className="relative container text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-white mb-6 font-headline">
              Empowering Every Industry to Go Global
            </h1>
            <p className="text-red-100 max-w-3xl mx-auto">
              From traditional crafts to cutting-edge technology, we help
              businesses across all industries reach international markets and
              achieve global success
            </p>
          </motion.div>
        </div>
      </section>

      {/* Industries Grid */}
      <section className="py-20 bg-background">
        <div className="container">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-foreground mb-4 font-headline">Industries We Serve</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Specialized export solutions tailored for diverse sectors of Indian
              industry
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {industries.map((industry, index) => (
              <motion.div
                key={index}
                className="group relative overflow-hidden rounded-2xl shadow-lg cursor-pointer"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: index * 0.05 }}
                whileHover={{
                  y: -12,
                  boxShadow: '0 25px 50px rgba(0,0,0,0.15)',
                }}
              >
                {/* Background Image */}
                <div className="absolute inset-0">
                  {industry.image && <Image
                    src={industry.image}
                    alt={industry.title}
                    fill
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />}
                  <div
                    className={`absolute inset-0 bg-gradient-to-br ${industry.color} opacity-80 group-hover:opacity-90 transition-opacity`}
                  />
                </div>

                {/* Content */}
                <div className="relative p-6 h-80 flex flex-col justify-between text-white">
                  <div>
                    <motion.div
                      className="w-14 h-14 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center mb-4"
                      whileHover={{ rotate: 360, scale: 1.1 }}
                      transition={{ duration: 0.6 }}
                    >
                      <industry.icon size={28} />
                    </motion.div>
                    <h3 className="text-white mb-3 font-headline">{industry.title}</h3>
                    <p className="text-white/90 text-sm">
                      {industry.description}
                    </p>
                  </div>

                  <motion.div
                    className="flex items-center text-sm opacity-0 group-hover:opacity-100 transition-opacity"
                    initial={{ x: -10 }}
                    whileHover={{ x: 0 }}
                  >
                    <span>Explore More</span>
                    <ArrowRight className="ml-2" size={16} />
                  </motion.div>
                </div>

                {/* Hover Overlay */}
                <motion.div
                  className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"
                  initial={{ opacity: 0 }}
                  whileHover={{ opacity: 1 }}
                />
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-gray-50">
        <div className="container">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-foreground mb-4 font-headline">Our Industry Impact</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Real results across diverse sectors
            </p>
          </motion.div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              {
                value: '15+',
                label: 'Industries Served',
                color: 'text-blue-600',
              },
              {
                value: '500+',
                label: 'Export Partners',
                color: 'text-green-600',
              },
              {
                value: '50+',
                label: 'Countries',
                color: 'text-purple-600',
              },
              {
                value: '$100M+',
                label: 'Export Value',
                color: 'text-primary',
              },
            ].map((stat, index) => (
              <motion.div
                key={index}
                className="text-center"
                initial={{ opacity: 0, scale: 0.5 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <motion.div
                  className={`${stat.color} mb-2 text-5xl font-bold`}
                  initial={{ opacity: 0 }}
                  whileInView={{ opacity: 1 }}
                  transition={{ duration: 1, delay: index * 0.1 + 0.3 }}
                  viewport={{ once: true }}
                >
                  {stat.value}
                </motion.div>
                <p className="text-muted-foreground">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Success Stories */}
      <section className="py-20 bg-background">
        <div className="container">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-foreground mb-4 font-headline">Industry Success Stories</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              How we've helped businesses across different sectors achieve
              global success
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                industry: 'Textiles',
                company: 'Premium Fabrics Ltd.',
                achievement: 'Expanded to 15 European markets',
                growth: '+250% Revenue',
              },
              {
                industry: 'Food Processing',
                company: 'Spice Exports Co.',
                achievement: 'Built distribution in North America',
                growth: '+180% Growth',
              },
              {
                industry: 'Engineering',
                company: 'Precision Parts Inc.',
                achievement: 'Secured contracts in Middle East',
                growth: '+320% Export',
              },
            ].map((story, index) => (
              <motion.div
                key={index}
                className="bg-gradient-to-br from-gray-50 to-white p-8 rounded-2xl border-2 border-gray-100 hover:border-primary transition-all duration-300"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ y: -8 }}
              >
                <div className="text-primary text-sm mb-2">
                  {story.industry}
                </div>
                <h3 className="text-foreground mb-3 font-headline">{story.company}</h3>
                <p className="text-muted-foreground mb-4">
                  {story.achievement}
                </p>
                <div className="inline-block px-4 py-2 bg-green-100 text-green-700 rounded-lg">
                  {story.growth}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-primary to-red-700 text-white">
        <div className="container text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-white mb-6 font-headline">
              Let's Take Your Industry to the World
            </h2>
            <p className="text-red-100 mb-8 max-w-2xl mx-auto">
              No matter what industry you're in, we have the expertise and
              network to help you succeed globally. Let's start your export
              journey today.
            </p>

            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button asChild
                variant="secondary"
                size="lg"
                className="px-12 py-6 rounded-lg shadow-lg group"
              >
                <Link href="/contact">
                  Start Your Global Journey
                  <ArrowRight
                    className="ml-2 group-hover:translate-x-1 transition-transform"
                    size={20}
                  />
                </Link>
              </Button>
            </motion.div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
