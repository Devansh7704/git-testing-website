'use client';

import { motion } from 'framer-motion';
import {
  Mail,
  Phone,
  MapPin,
  Globe,
  Send,
  Clock,
  CheckCircle,
} from 'lucide-react';
import Link from 'next/link';
import { ContactForm } from '@/components/contact-form';

export default function ContactPage() {
  const contactInfo = [
    {
      icon: MapPin,
      title: 'Visit Us',
      content: 'Ahmedabad, Gujarat, India',
      subContent: 'Business Hub of Western India',
    },
    {
      icon: Phone,
      title: 'Call Us',
      content: '+91 XXX XXX XXXX',
      subContent: 'Mon-Fri, 9:00 AM - 6:00 PM IST',
    },
    {
      icon: Mail,
      title: 'Email Us',
      content: 'info@globalascent.com',
      subContent: 'We reply within 24 hours',
    },
    {
      icon: Globe,
      title: 'Website',
      content: 'www.globalascent.com',
      subContent: 'Explore our services online',
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden pt-20">
        <div className="absolute inset-0 bg-gradient-to-br from-primary to-red-700" />
        <motion.div
          className="absolute inset-0 opacity-10"
          animate={{
            backgroundPosition: ['0% 0%', '100% 100%'],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            repeatType: 'reverse',
          }}
          style={{
            backgroundImage:
              'radial-gradient(circle, white 2px, transparent 2px)',
            backgroundSize: '50px 50px',
          }}
        />

        <div className="relative container text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h1 className="text-white mb-6 font-headline">
              Let's Build Your Global Presence
            </h1>
            <p className="text-red-100 max-w-3xl mx-auto">
              Ready to take your business to international markets? Get in touch
              with our team of export specialists
            </p>
          </motion.div>
        </div>
      </section>

      {/* Contact Info Cards */}
      <section className="py-20 bg-background">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-20">
            {contactInfo.map((info, index) => (
              <motion.div
                key={index}
                className="bg-gradient-to-br from-gray-50 to-white p-6 rounded-xl border-2 border-gray-100 hover:border-primary transition-all duration-300"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ y: -8 }}
              >
                <motion.div
                  className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center mb-4"
                  whileHover={{ scale: 1.1, rotate: 360 }}
                  transition={{ duration: 0.6 }}
                >
                  <info.icon className="text-primary" size={24} />
                </motion.div>
                <h3 className="text-foreground mb-2 font-headline">{info.title}</h3>
                <p className="text-muted-foreground mb-1">{info.content}</p>
                <p className="text-gray-500 text-sm">{info.subContent}</p>
              </motion.div>
            ))}
          </div>

          {/* Form and Map Section */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
            >
              <ContactForm />
            </motion.div>

            {/* Map and Additional Info */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
            >
              <div className="bg-gradient-to-br from-gray-50 to-white p-8 rounded-2xl border-2 border-gray-100 mb-6">
                <h3 className="text-foreground mb-6 font-headline">Our Location</h3>

                {/* Map Placeholder */}
                <div className="relative h-64 bg-gray-200 rounded-xl overflow-hidden mb-6">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <MapPin className="text-primary" size={48} />
                  </div>
                  <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-transparent" />
                </div>

                <div className="space-y-4">
                  <div className="flex items-start">
                    <MapPin
                      className="text-primary mr-3 mt-1 flex-shrink-0"
                      size={20}
                    />
                    <div>
                      <p className="text-foreground">Global Ascent</p>
                      <p className="text-muted-foreground text-sm">
                        Ahmedabad, Gujarat, India
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start">
                    <Clock
                      className="text-primary mr-3 mt-1 flex-shrink-0"
                      size={20}
                    />
                    <div>
                      <p className="text-foreground">Business Hours</p>
                      <p className="text-muted-foreground text-sm">
                        Monday - Friday: 9:00 AM - 6:00 PM IST
                      </p>
                      <p className="text-muted-foreground text-sm">
                        Saturday: 10:00 AM - 2:00 PM IST
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Quick Links */}
              <div className="bg-gradient-to-br from-primary to-red-700 p-8 rounded-2xl text-white">
                <h3 className="text-white mb-4 font-headline">Quick Links</h3>
                <div className="space-y-3">
                  {[
                    { label: 'About Us', page: '/about' },
                    { label: 'Our Services', page: '/services' },
                    { label: 'Industries We Serve', page: '/industries' },
                    { label: 'Resources', page: '/resources' },
                  ].map((link, index) => (
                    <motion.div
                      key={index}
                      whileHover={{ x: 8 }}
                      className="block w-full"
                    >
                      <Link
                        href={link.page}
                        className="text-left text-white/90 hover:text-white hover:translate-x-2 transition-all"
                      >
                        → {link.label}
                      </Link>
                    </motion.div>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-20 bg-gray-50">
        <div className="container text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <div className="inline-flex items-center gap-2 mb-6">
              <div className="w-12 h-1 bg-primary"></div>
              <span className="text-primary">Made in India</span>
              <div className="w-12 h-1 bg-primary"></div>
            </div>

            <h2 className="text-foreground mb-6 font-headline">
              Together, let's make your business a global success story
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Join hundreds of Indian businesses that have transformed their
              operations and achieved international success with Global Ascent.
            </p>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
