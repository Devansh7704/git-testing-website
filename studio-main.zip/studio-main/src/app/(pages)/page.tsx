
"use client";

import { motion, useScroll, useTransform, AnimatePresence } from 'framer-motion';
import { ArrowRight, AlertTriangle, Target, TrendingUp, CheckCircle, Search, Megaphone, Users, Phone, ShieldCheck, Globe, Star, Zap, Quote, ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useRef, useState, useEffect } from 'react';
import Link from 'next/link';
import { ContactForm } from '@/components/contact-form';

export default function HomePage() {
  const heroRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: heroRef,
    offset: ['start start', 'end start'],
  });

  const y = useTransform(scrollYProgress, [0, 1], ['0%', '50%']);
  const opacity = useTransform(scrollYProgress, [0, 1], [1, 0]);
  
    const testimonials = [
    {
      name: 'Rajesh Kumar',
      company: 'Kumar Textiles Pvt. Ltd.',
      text: 'Rising Venture Services transformed our business. Within 6 months, we were exporting to 5 European countries. Their market research was invaluable.',
      rating: 5,
    },
    {
      name: 'Priya Sharma',
      company: 'Spice Garden Exports',
      text: 'The team at RVS found the perfect markets for us. Their exhibition support helped us secure long-term contracts with buyers in the Middle East.',
      rating: 5,
    },
    {
      name: 'Amit Patel',
      company: 'Precision Engineering Works',
      text: 'From documentation to buyer meetings, RVS handled everything professionally. We now export automotive parts to 8 countries. Highly recommended!',
      rating: 5,
    },
    {
      name: 'Meera Reddy',
      company: 'Heritage Handicrafts',
      text: 'As a small business, we never thought global expansion was possible. RVS made it happen. Our products now reach customers in USA, UK, and Australia.',
      rating: 5,
    },
    {
      name: 'Suresh Iyer',
      company: 'South Indian Foods Co.',
      text: 'The expertise and network that RVS provided was exceptional. They helped us navigate complex export regulations and find distributors in North America.',
      rating: 5,
    },
  ];

  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex(prevIndex => (prevIndex + 1) % testimonials.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [testimonials.length]);

  const nextTestimonial = () => {
    setCurrentIndex(prev => (prev + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setCurrentIndex(prev => (prev - 1 + testimonials.length) % testimonials.length);
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section ref={heroRef} className="relative flex items-center justify-center overflow-hidden" style={{height: 'calc(100vh - 5rem)'}}>
        <motion.div
          className="absolute inset-0 z-0"
          style={{ y }}
        >
          <div className="absolute inset-0 bg-gradient-to-br from-red-50 via-white to-gray-50" />
          <motion.div
            className="absolute inset-0 opacity-30"
            animate={{
              backgroundPosition: ['0% 0%', '100% 100%'],
            }}
            transition={{
              duration: 20,
              repeat: Infinity,
              repeatType: 'reverse',
            }}
            style={{
              backgroundImage: 'radial-gradient(hsl(var(--primary)) 1px, transparent 1px)',
              backgroundSize: '50px 50px',
            }}
          />
        </motion.div>

        <motion.div
          className="relative z-10 text-center container"
          style={{ opacity }}
        >
          <motion.h1
            className="text-foreground mb-6 font-headline"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
          >
            Empowering Indian Businesses
            <br />
            <span className="text-primary">to Go Global</span>
          </motion.h1>
          
          <motion.p
            className="text-muted-foreground mb-8 max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            viewport={{ once: true }}
          >
            Your trusted partner in navigating international markets, building global connections,
            and transforming Indian enterprises into worldwide success stories.
          </motion.p>

          <motion.div
            className="flex flex-col sm:flex-row gap-4 justify-center"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            viewport={{ once: true }}
          >
            <motion.div className="w-full sm:w-auto" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button
                onClick={() => {
                  document.getElementById('contact-form')?.scrollIntoView({ behavior: 'smooth' });
                }}
                size="lg"
                className="w-full sm:w-auto px-8 py-6 rounded-md shadow-lg group text-lg"
              >
                Book Free Consultation
                <motion.div
                  className="ml-2 inline-block"
                  animate={{ x: [0, 5, 0] }}
                  transition={{ duration: 1.5, repeat: Infinity }}
                >
                  <ArrowRight size={20} />
                </motion.div>
              </Button>
            </motion.div>
            
            <motion.div className="w-full sm:w-auto" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button asChild
                variant="outline"
                size="lg"
                className="w-full sm:w-auto border-foreground px-8 py-6 rounded-md shadow-lg text-lg"
              >
                <Link href="/services">Explore Services</Link>
              </Button>
            </motion.div>
          </motion.div>
        </motion.div>

        <motion.div
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 1.5, repeat: Infinity }}
        >
          <div className="w-6 h-10 border-2 border-gray-400 rounded-full flex items-start justify-center p-2">
            <motion.div
              className="w-1 h-2 bg-gray-600 rounded-full"
              animate={{ y: [0, 12, 0] }}
              transition={{ duration: 1.5, repeat: Infinity }}
            />
          </div>
        </motion.div>
      </section>

      {/* Problem, Solution, Outcome Cards */}
      <section className="py-20 bg-white">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div
              className="bg-gradient-to-br from-red-50 to-white p-8 rounded-2xl border-2 border-red-100"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              whileHover={{ y: -8 }}
            >
              <motion.div
                className="w-16 h-16 bg-primary rounded-xl flex items-center justify-center mb-6"
                whileHover={{ rotate: 360 }}
                transition={{ duration: 0.6 }}
              >
                <AlertTriangle className="text-white" size={32} />
              </motion.div>
              <h3 className="text-gray-900 mb-4 font-headline">Problem</h3>
              <p className="text-gray-700 text-base">
                Indian businesses struggle to identify the right international markets, connect with verified buyers, and navigate complex export regulations.
              </p>
            </motion.div>

            <motion.div
              className="bg-gradient-to-br from-green-50 to-white p-8 rounded-2xl border-2 border-green-100"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              viewport={{ once: true }}
              whileHover={{ y: -8 }}
            >
              <motion.div
                className="w-16 h-16 bg-green-600 rounded-xl flex items-center justify-center mb-6"
                whileHover={{ rotate: 360 }}
                transition={{ duration: 0.6 }}
              >
                <Target className="text-white" size={32} />
              </motion.div>
              <h3 className="text-gray-900 mb-4 font-headline">Solution</h3>
              <p className="text-gray-700 text-base">
                Rising Venture Services provides end-to-end export development solutions — from market research to buyer connections, making global expansion seamless.
              </p>
            </motion.div>

            <motion.div
              className="bg-gradient-to-br from-blue-50 to-white p-8 rounded-2xl border-2 border-blue-100"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              viewport={{ once: true }}
              whileHover={{ y: -8 }}
            >
              <motion.div
                className="w-16 h-16 bg-blue-600 rounded-xl flex items-center justify-center mb-6"
                whileHover={{ rotate: 360 }}
                transition={{ duration: 0.6 }}
              >
                <TrendingUp className="text-white" size={32} />
              </motion.div>
              <h3 className="text-gray-900 mb-4 font-headline">Outcome</h3>
              <p className="text-gray-700 text-base">
                Our clients experience significant revenue growth, enter new markets confidently, and build lasting international partnerships.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Services Preview */}
      <section className="py-20 bg-gray-50">
        <div className="container">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-gray-900 mb-4 font-headline">Our Core Services</h2>
            <p className="text-gray-600 max-w-3xl mx-auto">
              Comprehensive export development solutions tailored to your business needs
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            {[
              {
                icon: Search,
                title: 'Market Research & Insights',
                description: 'In-depth market intelligence to identify profitable regions, policies, and opportunities.',
                features: [
                  'Potential export countries identification',
                  'Import duties, incentives, trade policies analysis',
                  'Entry barriers and compliance requirements',
                  'Competition mapping and analysis',
                  'Quality certifications and risk assessment',
                ],
                quote: 'Know where to sell, what to sell, and how to sell.',
                color: 'from-blue-500 to-blue-600',
              },
              {
                icon: Megaphone,
                title: 'Marketing & Branding',
                description: 'We make your brand globally competitive with professional marketing materials.',
                features: [
                  'Brochures, catalogs, and videos',
                  'Reels, posters, social creatives',
                  'Exhibition consultation & setup',
                  'International standard visual assets',
                ],
                quote: 'Make your brand look global and sell global.',
                color: 'from-purple-500 to-purple-600',
              },
              {
                icon: Users,
                title: 'Buyers & Global Connections',
                description: 'Connect with verified buyers and expand your international network.',
                features: [
                  'Verified buyer databases across sectors',
                  'Support in B2B meetings (physical & virtual)',
                  'Guidance on negotiations and presentations',
                  'Real connections that lead to real business',
                ],
                quote: 'Real connections that lead to real business.',
                color: 'from-green-500 to-green-600',
              },
            ].map((service, index) => (
              <motion.div
                key={index}
                className="bg-white rounded-2xl shadow-lg overflow-hidden border-2 border-gray-100 hover:border-primary transition-all duration-300 group"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ y: -8 }}
              >
                <div className={`bg-gradient-to-r ${service.color} p-6 text-white`}>
                  <motion.div
                    className="w-14 h-14 bg-white/20 rounded-xl flex items-center justify-center mb-4"
                    whileHover={{ rotate: 360, scale: 1.1 }}
                    transition={{ duration: 0.6 }}
                  >
                    <service.icon size={28} />
                  </motion.div>
                  <h3 className="text-white font-headline">{service.title}</h3>
                </div>

                <div className="p-6">
                  <p className="text-gray-600 mb-6 text-base">{service.description}</p>
                  
                  <ul className="space-y-3 mb-6">
                    {service.features.map((feature, fIndex) => (
                      <motion.li
                        key={fIndex}
                        className="flex items-start text-sm text-gray-700"
                        initial={{ opacity: 0, x: -10 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.3, delay: index * 0.1 + fIndex * 0.05 }}
                        viewport={{ once: true }}
                      >
                        <CheckCircle className="text-green-500 mr-2 mt-0.5 flex-shrink-0" size={16} />
                        <span>{feature}</span>
                      </motion.li>
                    ))}
                  </ul>

                  <div className="border-t border-gray-200 pt-4">
                    <p className="text-primary italic text-base">"{service.quote}"</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          <motion.div
            className="text-center"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button asChild
                size="lg"
                className="px-12 py-6 rounded-md shadow-lg group text-lg"
              >
                <Link href="/services">
                  Explore All Services
                  <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" size={20} />
                </Link>
              </Button>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Why Choose RVS */}
      <section className="py-20 bg-white overflow-hidden">
        <div className="container">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-gray-900 mb-4 font-headline">Why Choose Rising Venture Services?</h2>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            {[
              {
                number: '01',
                title: 'Expert Market Knowledge',
                description: 'Deep understanding of global markets, trade policies, and industry-specific requirements.',
              },
              {
                number: '02',
                title: 'Verified Buyer Network',
                description: 'Access to a vast database of verified international buyers across multiple sectors.',
              },
              {
                number: '03',
                title: 'End-to-End Support',
                description: 'From market research to post-sale support, we handle every aspect of your export journey.',
              },
              {
                number: '04',
                title: 'Proven Success Record',
                description: '500+ businesses successfully expanded globally with our guidance and support.',
              },
            ].map((item, index) => (
              <motion.div
                key={index}
                className="flex gap-6"
                initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8, delay: index * 0.2 }}
                viewport={{ once: true }}
              >
                <motion.div
                  className="text-6xl font-bold text-red-100"
                  whileInView={{ scale: [0, 1.2, 1] }}
                  transition={{ duration: 0.6, delay: index * 0.2 }}
                  viewport={{ once: true }}
                >
                  {item.number}
                </motion.div>
                <div className="flex-1">
                  <h3 className="text-gray-900 mb-3 font-headline">{item.title}</h3>
                  <p className="text-gray-600 text-base">{item.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
       <section className="py-20 bg-gray-50 overflow-hidden">
        <div className="container">
           <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-gray-900 mb-4 font-headline">What Our Clients Say</h2>
             <p className="text-gray-600 max-w-2xl mx-auto">
              Real stories from businesses we've helped go global
            </p>
          </motion.div>

           <div className="relative max-w-5xl mx-auto">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentIndex}
                className="bg-gradient-to-br from-gray-50 to-white p-8 md:p-12 rounded-3xl shadow-2xl border-2 border-gray-100"
                initial={{ opacity: 0, x: 100 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -100 }}
                transition={{ duration: 0.5 }}
              >
                <motion.div
                  className="absolute -top-6 left-8 w-16 h-16 bg-primary rounded-full flex items-center justify-center shadow-lg"
                  animate={{ rotate: [0, 10, -10, 0] }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  <Quote className="text-white" size={32} />
                </motion.div>

                <div className="mt-8">
                   <div className="flex items-center mb-4">
                    {[...Array(testimonials[currentIndex].rating)].map(
                      (_, i) => (
                        <motion.div
                          key={i}
                          initial={{ opacity: 0, scale: 0 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ duration: 0.3, delay: i * 0.1 }}
                        >
                          <Star
                            className="text-yellow-500 fill-yellow-500"
                            size={24}
                          />
                        </motion.div>
                      )
                    )}
                  </div>
                  <p className="text-muted-foreground mb-8 text-lg italic">
                    "{testimonials[currentIndex].text}"
                  </p>
                  <div>
                    <h3 className="text-foreground font-headline">
                      {testimonials[currentIndex].name}
                    </h3>
                    <p className="text-muted-foreground">
                      {testimonials[currentIndex].company}
                    </p>
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>

            {/* Navigation Buttons */}
             <div className="flex items-center justify-center gap-4 mt-8">
              <motion.button
                onClick={prevTestimonial}
                className="w-12 h-12 bg-white border-2 border-gray-200 rounded-full flex items-center justify-center hover:bg-primary hover:border-primary hover:text-white transition-colors shadow-lg"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
              >
                <ChevronLeft size={24} />
              </motion.button>

              <div className="flex gap-2">
                {testimonials.map((_, index) => (
                  <motion.button
                    key={index}
                    onClick={() => setCurrentIndex(index)}
                    className={`h-2 rounded-full transition-all ${
                      index === currentIndex
                        ? 'w-8 bg-primary'
                        : 'w-2 bg-gray-300'
                    }`}
                    whileHover={{ scale: 1.2 }}
                  />
                ))}
              </div>

              <motion.button
                onClick={nextTestimonial}
                className="w-12 h-12 bg-white border-2 border-gray-200 rounded-full flex items-center justify-center hover:bg-primary hover:border-primary hover:text-white transition-colors shadow-lg"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
              >
                <ChevronRight size={24} />
              </motion.button>
            </div>
          </div>
          
          <motion.div 
            className="text-center mt-12"
             initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
               <Button asChild
                variant="outline"
                size="lg"
                className="border-2 border-foreground px-8 py-6 rounded-md shadow-lg text-lg group"
              >
                <Link href="/testimonials">
                  View All Testimonials 
                  <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" size={20}/>
                </Link>
              </Button>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* CTA Banner */}
      <section className="py-20 bg-gradient-to-br from-primary to-red-700 text-white">
        <div className="container text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-white mb-6 font-headline">Ready to Take Your Business Global?</h2>
            <p className="text-red-100 mb-8 max-w-3xl mx-auto">
              Get expert guidance and personalized support to expand your business into international markets.
              Book a free consultation with our export specialists today.
            </p>

            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button
                onClick={() => {
                  document.getElementById('contact-form')?.scrollIntoView({ behavior: 'smooth' });
                }}
                variant="secondary"
                size="lg"
                className="px-12 py-6 rounded-md shadow-lg group text-lg"
              >
                Book Free Consultation
                <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" size={20} />
              </Button>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Why Partner With Us */}
      <section className="py-20 bg-gray-50">
        <div className="container">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-gray-900 mb-4 font-headline">Why Partner With Us?</h2>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 [perspective:1000px]">
            {[
              { 
                icon: Zap, 
                title: 'End-to-End Support', 
                description: 'From market research to final delivery, we provide comprehensive support at every step of your export journey.' 
              },
              { 
                icon: Globe, 
                title: 'Global Network', 
                description: 'Leverage our extensive network of buyers, distributors, and partners across 50+ countries.' 
              },
              { 
                icon: Star, 
                title: 'Proven Track Record', 
                description: 'Our history of success speaks for itself, with over 500 businesses successfully launched into global markets.' 
              },
              { 
                icon: ShieldCheck, 
                title: 'Personalized Solutions', 
                description: 'We don\'t believe in one-size-fits-all. Every strategy is tailored to your unique business needs and goals.'
              },
            ].map((item, index) => (
              <motion.div
                key={index}
                className="group h-64 w-full cursor-pointer"
                initial={{ opacity: 0, y: 50, rotateX: -20 }}
                whileInView={{ opacity: 1, y: 0, rotateX: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <div className="relative h-full w-full rounded-xl shadow-xl transition-all duration-500 [transform-style:preserve-3d] group-hover:[transform:rotateY(180deg)]">
                  {/* Front of Card */}
                  <div className="absolute inset-0 bg-white p-6 rounded-xl flex flex-col items-center justify-center [backface-visibility:hidden]">
                    <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                      <item.icon className="text-primary" size={40} />
                    </div>
                    <h3 className="text-foreground text-center font-headline text-lg">
                      {item.title}
                    </h3>
                  </div>

                  {/* Back of Card */}
                  <div className="absolute inset-0 h-full w-full rounded-xl bg-primary p-6 text-primary-foreground [transform:rotateY(180deg)] [backface-visibility:hidden]">
                    <div className="flex min-h-full flex-col items-center justify-center text-center">
                      <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                      <p className="text-sm text-primary-foreground/80">
                        {item.description}
                      </p>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Form */}
      <section id="contact-form" className="py-20 bg-white">
        <div className="container max-w-4xl">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <ContactForm />
          </motion.div>
        </div>
      </section>
    </div>
  );
}




    