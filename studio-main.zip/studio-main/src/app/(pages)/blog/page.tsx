
'use client';

import { motion } from 'framer-motion';
import {
  Search,
  ArrowRight,
  BookOpen,
  Calendar,
  User,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import Image from 'next/image';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';

export default function BlogPage() {
    const featuredPost = {
        category: 'Market Analysis',
        title: 'Top 10 Export Destinations for Indian Products in 2025',
        excerpt: 'Discover the most promising markets for Indian exporters this year, with in-depth analysis on trade policies, consumer demand, and competitive landscapes. This report provides actionable insights to help you make informed decisions for your global expansion strategy.',
        author: 'Dr. Ananya Sharma',
        date: 'March 1, 2025',
        readTime: '8 min read',
        image: 'https://picsum.photos/seed/blog-featured/1200/600',
    };

    const blogPosts = [
        {
            category: 'Export Strategy',
            title: 'Navigating Post-Brexit Trade with the UK',
            excerpt: 'An essential guide to exporting to the United Kingdom after Brexit, covering new regulations, customs procedures, and market opportunities for Indian businesses.',
            author: 'Rohan Mehta',
            date: 'Feb 28, 2025',
            readTime: '7 min read',
            image: 'https://picsum.photos/seed/blog-1/600/400',
        },
        {
            category: 'Digital Marketing',
            title: 'Digital Marketing for Global B2B Sales',
            excerpt: 'Learn how to leverage digital channels like SEO, LinkedIn, and email marketing for international business development and lead generation.',
            author: 'Priya Desai',
            date: 'Feb 25, 2025',
            readTime: '6 min read',
            image: 'https://picsum.photos/seed/blog-2/600/400',
        },
        {
            category: 'Sustainability',
            title: 'Sustainability in Export Business: Meeting Global ESG Standards',
            excerpt: 'Understand the growing importance of Environmental, Social, and Governance (ESG) standards and how to meet green certification requirements for global markets.',
            author: 'Arjun Verma',
            date: 'Feb 20, 2025',
            readTime: '8 min read',
            image: 'https://picsum.photos/seed/blog-3/600/400',
        },
        {
            category: 'Logistics',
            title: 'Optimizing Your Supply Chain for International Shipping',
            excerpt: 'Tips and strategies for creating a resilient and cost-effective supply chain, from packaging and labeling to choosing the right freight forwarder.',
            author: 'Sunita Patil',
            date: 'Feb 15, 2025',
            readTime: '9 min read',
            image: 'https://picsum.photos/seed/blog-4/600/400',
        },
        {
            category: 'Finance',
            title: 'Understanding Letters of Credit and Other Trade Finance Tools',
            excerpt: 'A comprehensive overview of the financial instruments that can secure your payments and facilitate smoother international transactions.',
            author: 'Vikram Singh',
            date: 'Feb 10, 2025',
            readTime: '7 min read',
            image: 'https://picsum.photos/seed/blog-5/600/400',
        },
        {
            category: 'Legal',
            title: 'Intellectual Property Protection in Global Markets',
            excerpt: 'Learn how to protect your trademarks, patents, and copyrights when you start selling your products in new countries.',
            author: 'Neha Gupta',
            date: 'Feb 5, 2025',
            readTime: '6 min read',
            image: 'https://picsum.photos/seed/blog-6/600/400',
        },
    ];

    const categories = ['All', 'Market Analysis', 'Export Strategy', 'Digital Marketing', 'Sustainability', 'Logistics', 'Finance', 'Legal'];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-to-br from-primary to-red-700 overflow-hidden pt-20">
        <motion.div
          className="absolute inset-0 opacity-10"
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.1 }}
          transition={{ duration: 0.8 }}
          style={{
            backgroundImage:
              'radial-gradient(circle, white 2px, transparent 2px)',
            backgroundSize: '50px 50px',
          }}
        />

        <div className="relative container text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-white mb-6 font-headline">
              The Global Ascent Blog
            </h1>
            <p className="text-red-100 max-w-3xl mx-auto">
              Your source for expert insights, industry trends, and actionable advice on navigating the world of international trade.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Featured Post */}
        <section className="py-20 bg-background">
            <div className="container">
                <motion.div
                    className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center"
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8 }}
                >
                    <div className="order-2 lg:order-1">
                        <Badge variant="secondary" className="mb-4">{featuredPost.category}</Badge>
                        <h2 className="text-foreground mb-4 font-headline">{featuredPost.title}</h2>
                        <p className="text-muted-foreground mb-6">{featuredPost.excerpt}</p>
                        <div className="flex items-center text-sm text-gray-500 mb-8">
                            <div className="flex items-center">
                                <User size={14} className="mr-2"/> <span>{featuredPost.author}</span>
                            </div>
                            <span className="mx-2">•</span>
                            <div className="flex items-center">
                                <Calendar size={14} className="mr-2"/> <span>{featuredPost.date}</span>
                            </div>
                            <span className="mx-2">•</span>
                            <div className="flex items-center">
                                <BookOpen size={14} className="mr-2"/> <span>{featuredPost.readTime}</span>
                            </div>
                        </div>
                        <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                            <Button asChild size="lg" className="group">
                                <Link href="#">Read Full Article <ArrowRight size={20} className="ml-2 group-hover:translate-x-1 transition-transform" /></Link>
                            </Button>
                        </motion.div>
                    </div>
                    <motion.div
                        className="order-1 lg:order-2 rounded-2xl overflow-hidden shadow-2xl"
                        whileHover={{ scale: 1.03 }}
                    >
                        <Image src={featuredPost.image} alt={featuredPost.title} width={600} height={400} className="w-full h-full object-cover"/>
                    </motion.div>
                </motion.div>
            </div>
        </section>

      {/* Blog Feed & Filters */}
      <section className="py-20 bg-gray-50">
        <div className="container">
          <motion.div
            className="flex flex-col md:flex-row justify-between items-center mb-12 gap-6"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="relative w-full md:max-w-md">
                <Input type="text" placeholder="Search articles..." className="pl-10" />
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={20} />
            </div>
            <div className="flex flex-wrap items-center gap-2">
                {categories.map(category => (
                    <Button key={category} variant={category === 'All' ? 'default' : 'outline'} size="sm" className="rounded-full">
                        {category}
                    </Button>
                ))}
            </div>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {blogPosts.map((post, index) => (
              <motion.div
                key={index}
                className="bg-white rounded-2xl shadow-lg overflow-hidden border-2 border-transparent hover:border-primary transition-all duration-300 group"
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ y: -8 }}
              >
                  <div className="relative h-56 overflow-hidden">
                      <Image src={post.image} alt={post.title} fill className="object-cover transition-transform duration-500 group-hover:scale-105" />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                      <Badge className="absolute top-4 left-4">{post.category}</Badge>
                  </div>
                <div className="p-6">
                  <h3 className="text-foreground mb-3 font-headline group-hover:text-primary transition-colors">{post.title}</h3>
                  <p className="text-muted-foreground text-sm mb-4 line-clamp-3">{post.excerpt}</p>
                   <div className="flex items-center text-xs text-gray-500 mb-4">
                        <div className="flex items-center">
                            <User size={12} className="mr-1"/> <span>{post.author}</span>
                        </div>
                        <span className="mx-2">•</span>
                        <div className="flex items-center">
                            <Calendar size={12} className="mr-1"/> <span>{post.date}</span>
                        </div>
                    </div>
                  <Link href="#" className="text-primary font-semibold text-sm flex items-center group">
                    Read More
                    <ArrowRight size={16} className="ml-1 transition-transform group-hover:translate-x-1" />
                  </Link>
                </div>
              </motion.div>
            ))}
          </div>
            <div className="text-center mt-16">
                 <Button variant="outline" size="lg">Load More Articles</Button>
            </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-20 bg-background">
        <div className="container max-w-4xl">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="bg-gradient-to-br from-primary to-red-700 p-8 md:p-12 rounded-3xl text-center text-white">
              <motion.div
                className="inline-flex w-16 h-16 bg-white/20 rounded-full items-center justify-center mb-6"
                animate={{ scale: [1, 1.1, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <BookOpen size={32} />
              </motion.div>

              <h2 className="text-white mb-4 font-headline">Stay Ahead of the Curve</h2>
              <p className="text-red-100 mb-8 max-w-2xl mx-auto">
                Subscribe to our newsletter for weekly market updates, export
                tips, and exclusive insights delivered straight to your inbox.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
                <Input
                  type="email"
                  placeholder="Enter your email"
                  className="flex-1 px-6 py-3 rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-white"
                />
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Button
                    variant="secondary"
                    className="px-8 py-3 rounded-lg whitespace-nowrap"
                  >
                    Subscribe
                  </Button>
                </motion.div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
