'use client';

import { motion, AnimatePresence } from 'framer-motion';
import {
  Quote,
  Star,
  ChevronLeft,
  ChevronRight,
  ArrowRight,
} from 'lucide-react';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import Link from 'next/link';

export default function TestimonialsPage() {
  const [currentIndex, setCurrentIndex] = useState(0);

  const testimonials = [
    {
      name: 'Rajesh Kumar',
      company: 'Kumar Textiles Pvt. Ltd.',
      location: 'Surat, Gujarat',
      industry: 'Textiles',
      text: 'Rising Venture Services transformed our business completely. Within 6 months, we were exporting to 5 European countries. Their market research and buyer connections were invaluable.',
      rating: 5,
      growth: '250% increase in revenue',
    },
    {
      name: 'Priya Sharma',
      company: 'Spice Garden Exports',
      location: 'Kerala',
      industry: 'Food Processing',
      text: 'The team at RVS understood our products and found the perfect markets for us. Their exhibition support helped us secure long-term contracts with buyers in the Middle East.',
      rating: 5,
      growth: '180% export growth',
    },
    {
      name: 'Amit Patel',
      company: 'Precision Engineering Works',
      location: 'Pune, Maharashtra',
      industry: 'Engineering',
      text: 'From documentation to buyer meetings, RVS handled everything professionally. We now export automotive parts to 8 countries. Highly recommended!',
      rating: 5,
      growth: '320% business expansion',
    },
    {
      name: 'Meera Reddy',
      company: 'Heritage Handicrafts',
      location: 'Jaipur, Rajasthan',
      industry: 'Handicrafts',
      text: 'As a small business, we never thought global expansion was possible. RVS made it happen. Our handcrafted products now reach customers in USA, UK, and Australia.',
      rating: 5,
      growth: '400% market reach',
    },
    {
      name: 'Suresh Iyer',
      company: 'South Indian Foods Co.',
      location: 'Chennai, Tamil Nadu',
      industry: 'Food & Beverages',
      text: 'The expertise and network that RVS provided was exceptional. They helped us navigate complex export regulations and find distributors in North America.',
      rating: 5,
      growth: '200% revenue increase',
    },
    {
      name: 'Vikram Singh',
      company: 'Modern Pharma Industries',
      location: 'Ahmedabad, Gujarat',
      industry: 'Pharmaceuticals',
      text: "RVS's strategic guidance helped us enter regulated markets smoothly. Their compliance support and buyer verification saved us months of effort.",
      rating: 5,
      growth: '150% export volume',
    },
  ];

  const nextTestimonial = () => {
    setCurrentIndex(prev => (prev + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setCurrentIndex(prev => (prev - 1 + testimonials.length) % testimonials.length);
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-to-br from-primary to-red-700 text-white overflow-hidden pt-20">
        <motion.div
          className="absolute inset-0 opacity-10"
          animate={{
            backgroundPosition: ['0% 0%', '100% 100%'],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            repeatType: 'reverse',
          }}
          style={{
            backgroundImage:
              'radial-gradient(circle, white 2px, transparent 2px)',
            backgroundSize: '50px 50px',
          }}
        />

        <div className="relative container text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h1 className="text-white mb-6 font-headline">Hear from Our Clients</h1>
            <p className="text-red-100 max-w-3xl mx-auto">
              Real stories from real businesses that have achieved global
              success with Global Ascent
            </p>
          </motion.div>
        </div>
      </section>

      {/* Featured Testimonial Carousel */}
      <section className="py-20 bg-background">
        <div className="container max-w-5xl">
          <div className="relative">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentIndex}
                className="bg-gradient-to-br from-gray-50 to-white p-8 md:p-12 rounded-3xl shadow-2xl border-2 border-gray-100"
                initial={{ opacity: 0, x: 100 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -100 }}
                transition={{ duration: 0.5 }}
              >
                <motion.div
                  className="absolute -top-6 left-8 w-16 h-16 bg-primary rounded-full flex items-center justify-center shadow-lg"
                  animate={{ rotate: [0, 10, -10, 0] }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  <Quote className="text-white" size={32} />
                </motion.div>

                <div className="mt-8">
                  <div className="flex items-center mb-4">
                    {[...Array(testimonials[currentIndex].rating)].map(
                      (_, i) => (
                        <motion.div
                          key={i}
                          initial={{ opacity: 0, scale: 0 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ duration: 0.3, delay: i * 0.1 }}
                        >
                          <Star
                            className="text-yellow-500 fill-yellow-500"
                            size={24}
                          />
                        </motion.div>
                      )
                    )}
                  </div>

                  <p className="text-muted-foreground mb-8 text-lg italic">
                    "{testimonials[currentIndex].text}"
                  </p>

                  <div className="flex items-center justify-between flex-wrap gap-4">
                    <div>
                      <h3 className="text-foreground font-headline">
                        {testimonials[currentIndex].name}
                      </h3>
                      <p className="text-muted-foreground">
                        {testimonials[currentIndex].company}
                      </p>
                      <p className="text-gray-500 text-sm">
                        {testimonials[currentIndex].location} •{' '}
                        {testimonials[currentIndex].industry}
                      </p>
                    </div>

                    <div className="bg-green-100 text-green-700 px-6 py-3 rounded-lg">
                      {testimonials[currentIndex].growth}
                    </div>
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>

            {/* Navigation Buttons */}
            <div className="flex items-center justify-center gap-4 mt-8">
              <motion.button
                onClick={prevTestimonial}
                className="w-12 h-12 bg-white border-2 border-gray-200 rounded-full flex items-center justify-center hover:bg-primary hover:border-primary hover:text-white transition-colors shadow-lg"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
              >
                <ChevronLeft size={24} />
              </motion.button>

              <div className="flex gap-2">
                {testimonials.map((_, index) => (
                  <motion.button
                    key={index}
                    onClick={() => setCurrentIndex(index)}
                    className={`h-2 rounded-full transition-all ${
                      index === currentIndex
                        ? 'w-8 bg-primary'
                        : 'w-2 bg-gray-300'
                    }`}
                    whileHover={{ scale: 1.2 }}
                  />
                ))}
              </div>

              <motion.button
                onClick={nextTestimonial}
                className="w-12 h-12 bg-white border-2 border-gray-200 rounded-full flex items-center justify-center hover:bg-primary hover:border-primary hover:text-white transition-colors shadow-lg"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
              >
                <ChevronRight size={24} />
              </motion.button>
            </div>
          </div>
        </div>
      </section>

      {/* All Testimonials Grid */}
      <section className="py-20 bg-gray-50">
        <div className="container">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-foreground mb-4 font-headline">
              Success Stories Across Industries
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Join our growing network of successful exporters
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={index}
                className="bg-white p-6 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 border-2 border-gray-100 hover:border-primary"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ y: -8 }}
              >
                <div className="flex items-center mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star
                      key={i}
                      className="text-yellow-500 fill-yellow-500"
                      size={16}
                    />
                  ))}
                </div>

                <p className="text-muted-foreground mb-6 text-sm italic">
                  "{testimonial.text.slice(0, 120)}..."
                </p>

                <div className="border-t border-gray-200 pt-4">
                  <p className="text-foreground">{testimonial.name}</p>
                  <p className="text-muted-foreground text-sm">
                    {testimonial.company}
                  </p>
                  <p className="text-gray-500 text-xs mt-1">
                    {testimonial.industry}
                  </p>

                  <div className="mt-3 inline-block px-3 py-1 bg-green-100 text-green-700 rounded text-xs">
                    {testimonial.growth}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-background">
        <div className="container">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-foreground mb-4 font-headline">Client Success Metrics</h2>
          </motion.div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { value: '500+', label: 'Happy Clients' },
              { value: '95%', label: 'Satisfaction Rate' },
              { value: '250%', label: 'Avg. Growth' },
              { value: '50+', label: 'Countries Reached' },
            ].map((stat, index) => (
              <motion.div
                key={index}
                className="text-center"
                initial={{ opacity: 0, scale: 0.5 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <motion.div
                  className="text-primary mb-2 text-5xl font-bold"
                  initial={{ opacity: 0 }}
                  whileInView={{ opacity: 1 }}
                  transition={{ duration: 1, delay: index * 0.1 + 0.3 }}
                  viewport={{ once: true }}
                >
                  {stat.value}
                </motion.div>
                <p className="text-muted-foreground">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-primary to-red-700 text-white">
        <div className="container text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-white mb-6 font-headline">
              Join Our Network of Successful Exporters
            </h2>
            <p className="text-red-100 mb-8 max-w-2xl mx-auto">
              Be the next success story. Let us help you take your business to
              global markets and achieve unprecedented growth.
            </p>

            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button asChild
                variant="secondary"
                size="lg"
                className="px-12 py-6 rounded-lg shadow-lg group"
              >
                <Link href="/contact">
                  Start Your Success Story
                  <ArrowRight
                    className="ml-2 group-hover:translate-x-1 transition-transform"
                    size={20}
                  />
                </Link>
              </Button>
            </motion.div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
