
'use client';

import { motion } from 'framer-motion';
import {
  Calendar,
  MapPin,
  ListChecks,
  LayoutGrid,
  Handshake,
  ArrowRight,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import Link from 'next/link';

export default function ExhibitionsPage() {
  const exhibitionServices = [
    {
      icon: ListChecks,
      title: 'Event Selection',
      description:
        'We identify the most relevant exhibitions for your industry and target markets',
    },
    {
      icon: LayoutGrid,
      title: 'Booth Management',
      description:
        'Complete booth design, setup, and onsite management for professional presence',
    },
    {
      icon: Handshake,
      title: 'B2B Coordination',
      description:
        'Pre-arranged meetings with verified buyers and potential partners',
    },
  ];

  const upcomingExhibitions = [
    {
      name: 'Bharat Buildcon',
      location: 'India',
      date: 'March 2025',
      description:
        "India's premier building materials and construction technology exhibition",
    },
    {
      name: 'European Manufacturing Expo',
      location: 'Germany',
      date: 'April 2025',
      description:
        'Connect with European buyers and explore new market opportunities',
    },
    {
      name: 'Asia Food & Beverage Show',
      location: 'Singapore',
      date: 'May 2025',
      description: 'Showcase Indian food products to Asian and global buyers',
    },
    {
      name: 'North American Trade Summit',
      location: 'USA',
      date: 'June 2025',
      description:
        'Meet potential buyers and partners from across North America',
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden bg-gradient-to-br from-primary to-red-700 pt-20">
        <motion.div
          className="absolute inset-0 opacity-10"
          animate={{
            backgroundPosition: ['0% 0%', '100% 100%'],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            repeatType: 'reverse',
          }}
          style={{
            backgroundImage:
              'radial-gradient(circle, white 2px, transparent 2px)',
            backgroundSize: '50px 50px',
          }}
        />

        <div className="relative container text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-white mb-6 font-headline">
              Global Trade Exhibitions
            </h1>
            <p className="text-red-100 max-w-3xl mx-auto">
              Connect with international buyers, expand your network, and
              showcase your products at premier trade shows around the world.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Our Exhibition Services */}
      <section className="py-20 bg-background">
        <div className="container">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-foreground mb-4 font-headline">
              Our Exhibition Services
            </h2>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {exhibitionServices.map((service, index) => (
              <motion.div
                key={index}
                className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-shadow duration-300 border-2 border-gray-100 hover:border-primary"
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ y: -8 }}
              >
                <div className="w-16 h-16 bg-primary/10 rounded-xl flex items-center justify-center mb-6">
                  <service.icon className="text-primary" size={32} />
                </div>
                <h3 className="text-foreground mb-3 font-headline">
                  {service.title}
                </h3>
                <p className="text-muted-foreground">{service.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Upcoming Exhibitions */}
      <section className="py-20 bg-gray-50">
        <div className="container">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-foreground mb-4 font-headline">
              Upcoming Exhibitions
            </h2>
          </motion.div>

          <div className="max-w-4xl mx-auto">
            <div className="space-y-6">
              {upcomingExhibitions.map((exhibition, index) => (
                <motion.div
                  key={index}
                  className="bg-white p-6 rounded-2xl shadow-md border-l-4 border-primary"
                  initial={{ opacity: 0, x: -30 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
                    <div className="mb-4 sm:mb-0">
                      <h3 className="text-foreground mb-1 font-headline">
                        {exhibition.name}
                      </h3>
                      <p className="text-muted-foreground text-sm max-w-md">
                        {exhibition.description}
                      </p>
                    </div>
                    <div className="text-right flex-shrink-0">
                      <div className="flex items-center justify-end text-muted-foreground text-sm mb-1">
                        <MapPin className="mr-2 text-primary" size={16} />
                        <span>{exhibition.location}</span>
                      </div>
                      <div className="flex items-center justify-end text-muted-foreground text-sm">
                        <Calendar className="mr-2 text-primary" size={16} />
                        <span>{exhibition.date}</span>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Proven Exhibition Success */}
      <section className="py-20 bg-background">
        <div className="container max-w-4xl text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-foreground mb-4 font-headline">
              Proven Exhibition Success
            </h2>
            <p className="text-muted-foreground leading-relaxed">
              We have successfully represented Indian manufacturers at major
              international exhibitions across 40+ countries, generating
              valuable leads and establishing long-term business
              relationships.
            </p>
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-primary to-red-700 text-white">
        <div className="container text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-white mb-6 font-headline">
              Exhibit with Confidence
            </h2>
            <p className="text-red-100 mb-8 max-w-2xl mx-auto">
              Ready to showcase your products on a global stage? Partner with us
              for end-to-end exhibition support.
            </p>

            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button asChild
                variant="secondary"
                size="lg"
                className="px-12 py-6 rounded-lg shadow-lg group"
              >
                <Link href="/contact">
                  Contact Us
                  <ArrowRight
                    className="ml-2 group-hover:translate-x-1 transition-transform"
                    size={20}
                  />
                </Link>
              </Button>
            </motion.div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
