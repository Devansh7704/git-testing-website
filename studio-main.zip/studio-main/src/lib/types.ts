import type { LucideIcon } from "lucide-react";

export type NavLink = {
  href: string;
  label: string;
};

export type Service = {
  icon: LucideIcon;
  title: string;
  description: string;
};

export type Industry = {
  imageId: string;
  title: string;
  description: string;
};

export type Testimonial = {
  quote: string;
  author: string;
  company: string;
};

export type Exhibition = {
  date: string;
  title: string;
  location: string;
  description: string;
};

export type Resource = {
  imageId: string;
  category: string;
  title: string;
  description: string;
  link: string;
};

export type TeamMember = {
  imageId: string;
  name: string;
  role: string;
};
