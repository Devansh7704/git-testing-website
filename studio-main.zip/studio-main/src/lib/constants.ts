import type { NavLink } from '@/lib/types';

export const NAV_LINKS: NavLink[] = [
  { href: '/', label: 'Home' },
  { href: '/about', label: 'About Us' },
  { href: '/services', label: 'Services' },
  { href: '/industries', label: 'Industries' },
  { href: '/testimonials', label: 'Testimonials' },
  { href: '/exhibitions', label: 'Exhibitions' },
  { href: '/blog', label: 'Blog' },
];

// Note: The following are not used with the new header/footer but are kept for potential future use.

export const SERVICE_LINKS: NavLink[] = [
    { href: '/services', label: 'Services Overview' },
    { href: '/services/web-uiux', label: 'Website & UI/UX Design' },
    { href: '/services/web-dev', label: 'Web Development' },
    { href: '/services/ai-chatbots', label: 'AI Chatbots & Automation' },
    { href: '/services/ai-creative', label: 'AI Creative Services' },
    { href: '/services/mobile-app', label: 'Mobile App Design' },
]

export const FOOTER_COMPANY_LINKS: NavLink[] = [
    { href: '/about', label: 'About Us' },
    { href: '/process', label: 'Our Process' },
    { href: '/work', label: 'Portfolio' },
    { href: '/blog', label: 'Blog' },
];

export const FOOTER_SERVICES_LINKS: NavLink[] = [
    { href: '/services/uiux-design', label: 'UI/UX Design' },
    { href: '/services/web-design', label: 'Website Design' },
    { href: '/services/mobile-app', label: 'Mobile App Design' },
    { href: '/services/branding', label: 'Branding & Identity' },
];
