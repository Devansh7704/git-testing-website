"use server";

import { z } from "zod";

const contactFormSchema = z.object({
  name: z.string().trim().min(2, { message: "Name must be at least 2 characters." }),
  email: z.string().email({ message: "Please enter a valid email address." }),
  phone: z.string().trim().min(10, { message: "Please enter a valid phone number." }),
  company: z.string().trim().optional(),
  industry: z.string().trim().min(1, { message: "Please select an industry." }),
  message: z.string().trim().min(10, { message: "Message must be at least 10 characters." }),
});

export type FormState = {
  success: boolean;
  message: string;
}

export async function submitContactForm(prevState: FormState, formData: FormData): Promise<FormState> {
  const data = Object.fromEntries(formData.entries());
  const parsed = contactFormSchema.safeParse(data);

  if (!parsed.success) {
    const error = parsed.error.errors[0];
    return { 
      success: false, 
      message: error.message 
    };
  }

  try {
    // In a real application, you would send an email here using a service like Resend, Nodemailer, or SendGrid.
    // For this example, we'll just log the data to the console and simulate a success response.
    console.log("New Contact Form Submission:", parsed.data);
    
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 1000));

    return { 
      success: true, 
      message: "Thank you for your message! We will get back to you soon." 
    };
  } catch (error) {
    console.error("Error submitting contact form:", error);
    return { 
      success: false, 
      message: "An unexpected error occurred. Please try again later." 
    };
  }
}
