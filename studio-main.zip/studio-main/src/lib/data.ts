import type { Service, Industry, Testimonial, Exhibition, Resource, TeamMember } from '@/lib/types';
import { Ship, Globe, Warehouse, Rocket, Briefcase, Users } from 'lucide-react';

export const services: Service[] = [
  {
    icon: Ship,
    title: "Global Freight Forwarding",
    description: "Seamless air, sea, and land freight solutions to connect your business with the world. We ensure timely and cost-effective delivery, every time."
  },
  {
    icon: Globe,
    title: "Market Entry Strategy",
    description: "Navigate new markets with confidence. Our experts provide comprehensive analysis and strategic planning to ensure a successful launch."
  },
  {
    icon: Warehouse,
    title: "Supply Chain Management",
    description: "Optimize your supply chain for efficiency and resilience. From procurement to last-mile delivery, we've got you covered."
  },
  {
    icon: Rocket,
    title: "Venture Scaling",
    description: "Accelerate your growth with our bespoke venture scaling services. We provide the resources and expertise to take your business to the next level."
  },
  {
    icon: Briefcase,
    title: "Regulatory Compliance",
    description: "Effortlessly navigate complex international trade regulations and compliance standards with our dedicated legal and customs team."
  },
  {
    icon: Users,
    title: "Cross-Cultural Consulting",
    description: "Bridge cultural gaps and build stronger international partnerships with our cross-cultural communication and business etiquette training."
  },
];

export const industries: Industry[] = [
  {
    imageId: "industry-tech",
    title: "Technology & Electronics",
    description: "We provide agile logistics and market access for the fast-paced tech industry, ensuring your products reach global customers securely and swiftly."
  },
  {
    imageId: "industry-healthcare",
    title: "Healthcare & Pharma",
    description: "Specialized, compliant supply chain solutions for the healthcare sector, handling sensitive and life-saving products with the utmost care."
  },
  {
    imageId: "industry-retail",
    title: "Retail & E-commerce",
    description: "Omnichannel logistics and international expansion strategies to help retail brands thrive in a competitive global marketplace."
  },
  {
    imageId: "industry-aerospace",
    title: "Aerospace & Defense",
    description: "Precision logistics and strategic support for the aerospace and defense industries, meeting stringent requirements for security and timeliness."
  }
];

export const testimonials: Testimonial[] = [
  {
    quote: "Global Ascent transformed our international expansion. Their market insights were invaluable, and their logistics network is second to none. A true partner in growth.",
    author: "Jane Doe",
    company: "CEO, InnovateTech"
  },
  {
    quote: "The professionalism and efficiency of the Global Ascent team are outstanding. They simplified a complex supply chain, saving us both time and money.",
    author: "John Smith",
    company: "COO, HealthFirst Pharma"
  },
  {
    quote: "Navigating customs and regulations was our biggest hurdle. Global Ascent made it seamless. We couldn't have entered the European market without them.",
    author: "Emily White",
    company: "Founder, StyleStitch"
  },
  {
    quote: "From strategy to execution, Global Ascent delivered. Their hands-on approach and deep industry knowledge gave us the confidence to scale globally.",
    author: "Michael Brown",
    company: "VP Operations, Quantum Dynamics"
  }
];

export const exhibitions: Exhibition[] = [
  {
    date: "October 14-16, 2024",
    title: "World Trade Symposium",
    location: "Singapore",
    description: "Join us at booth #A21 to discuss the future of global trade and supply chain innovation. Our CEO will be a keynote speaker."
  },
  {
    date: "November 5-7, 2024",
    title: "Global Innovators Summit",
    location: "Berlin, Germany",
    description: "We're excited to connect with the world's leading startups and venture capitalists. Find us in the main exhibition hall."
  },
  {
    date: "January 22-24, 2025",
    title: "International Logistics Expo",
    location: "Las Vegas, USA",
    description: "Discover our latest advancements in freight and supply chain technology. We'll be providing live demos and consultations."
  }
];

export const resources: Resource[] = [
  {
    imageId: "resource-logistics",
    category: "Logistics",
    title: "The Future of Sustainable Supply Chains",
    description: "Exploring how green logistics is not just good for the planet but also for your bottom line.",
    link: "#"
  },
  {
    imageId: "resource-market",
    category: "Market Analysis",
    title: "Emerging Markets to Watch in 2025",
    description: "Our in-depth analysis of the top 5 emerging markets and the opportunities they present for ventures.",
    link: "#"
  },
  {
    imageId: "resource-tech",
    category: "Technology",
    title: "How AI is Revolutionizing Freight Forwarding",
    description: "A look into how artificial intelligence is creating smarter, more predictive, and efficient logistics networks.",
    link: "#"
  }
];

export const team: TeamMember[] = [
    {
        imageId: 'team-1',
        name: 'Eleanor Vance',
        role: 'Founder & CEO'
    },
    {
        imageId: 'team-2',
        name: 'Marcus Thorne',
        role: 'Head of Global Logistics'
    },
    {
        imageId: 'team-3',
        name: 'Seraphina Chen',
        role: 'Director of Market Strategy'
    }
]
