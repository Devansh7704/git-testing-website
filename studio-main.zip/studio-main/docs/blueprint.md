# **App Name**: Global Ascent

## Core Features:

- Informational Pages: Displays information about the company, services, industries served, testimonials, and resources using the text in the user's prompt. Pages include Home, About Us, Services, Industries, Testimonials, Exhibitions, Resources and Contact.
- Contact Form: Allows users to submit inquiries and contact information.
- Exhibition Schedule: Highlights upcoming exhibitions and events that Rising Venture Services will be participating in.

## Style Guidelines:

- Primary color: Deep sky blue (#00BFFF), inspired by the global scope and trustworthiness of the company.
- Background color: Light cyan (#E0FFFF), a desaturated hue of the primary, for a clean and airy feel.
- Accent color: Slate blue (#6A5ACD), adds sophistication and highlights key elements.
- Headline font: 'Playfair', a serif font known for its high contrast, bringing a touch of elegance to the presentation; body font: 'PT Sans', a friendly sans-serif font
- Use clean, professional icons to represent different services and industries.
- Employ a grid-based layout for organized content presentation and easy navigation.
- Incorporate subtle transitions and animations to enhance user engagement and provide feedback.